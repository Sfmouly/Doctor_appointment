import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firebase_service.dart';
import 'widgets/appointment_card.dart';
import 'widgets/reject_dialog.dart';
import 'widgets/prescription_dialog.dart';

class DoctorDashboardScreen extends StatefulWidget {
  final String doctorId;

  DoctorDashboardScreen({required this.doctorId});

  @override
  _DoctorDashboardScreenState createState() => _DoctorDashboardScreenState();
}

class _DoctorDashboardScreenState extends State<DoctorDashboardScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseService _firebaseService = FirebaseService();

  Stream<QuerySnapshot> getDoctorAppointments() {
    return _firestore
        .collection('appointments')
        .where('doctorId', isEqualTo: widget.doctorId)
        .snapshots();
  }

  void updateAppointmentStatus(
    String appointmentId,
    String status, {
    String? comment,
  }) async {
    await _firestore.collection('appointments').doc(appointmentId).update({
      'status': status,
      'doctorComment': comment ?? '',
      'responseTime': FieldValue.serverTimestamp(),
    });
  }

  void _showRejectDialog(String appointmentId) {
    showDialog(
      context: context,
      builder:
          (context) => RejectDialog(
            onReject: (comment) {
              updateAppointmentStatus(
                appointmentId,
                'rejected',
                comment: comment,
              );
            },
          ),
    );
  }

  void _showPrescriptionDialog(String appointmentId) {
    showDialog(
      context: context,
      builder:
          (context) => PrescriptionDialog(
            onSubmit: (medication, dosage, advice) async {
              await _firestore.collection('prescriptions').add({
                'appointmentId': appointmentId,
                'medication': medication,
                'dosage': dosage,
                'advice': advice,
                'createdAt': FieldValue.serverTimestamp(),
              });
              await _firestore
                  .collection('appointments')
                  .doc(appointmentId)
                  .update({'status': 'completed'});
            },
          ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Doctor Dashboard'),
        backgroundColor: Colors.teal.shade700,
      ),
      body: StreamBuilder<QuerySnapshot>(
        stream: getDoctorAppointments(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(
              child: Text(
                'Error loading appointments',
                style: TextStyle(color: Colors.red),
              ),
            );
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          final appointments = snapshot.data!.docs;
          if (appointments.isEmpty) {
            return Center(child: Text('No appointments found'));
          }
          return ListView.builder(
            itemCount: appointments.length,
            itemBuilder: (context, index) {
              var appointment = appointments[index];
              var data = appointment.data() as Map<String, dynamic>;
              return Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                elevation: 6,
                margin: EdgeInsets.symmetric(vertical: 8, horizontal: 12),
                child: ListTile(
                  title: Text(
                    data['patientName'] ?? 'Unknown',
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Date: ${data['dateTime'] ?? 'N/A'}'),
                      Text('Status: ${data['status'] ?? ''}'),
                      if (data['doctorComment'] != null &&
                          data['doctorComment'].isNotEmpty)
                        Text('Comment: ${data['doctorComment']}'),
                    ],
                  ),
                  trailing: Wrap(
                    spacing: 8,
                    children: [
                      if (data['status'] == 'pending')
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal.shade700,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () {
                            updateAppointmentStatus(appointment.id, 'accepted');
                          },
                          child: Text('Accept'),
                        ),
                      if (data['status'] == 'pending')
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.red.shade700,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () {
                            _showRejectDialog(appointment.id);
                          },
                          child: Text('Reject'),
                        ),
                      if (data['status'] == 'accepted')
                        ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue.shade700,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () {
                            _showPrescriptionDialog(appointment.id);
                          },
                          child: Text('Prescribe'),
                        ),
                    ],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
