import 'package:flutter/material.dart';

class RejectDialog extends StatefulWidget {
  final Function(String) onReject;

  RejectDialog({required this.onReject});

  @override
  _RejectDialogState createState() => _RejectDialogState();
}

class _RejectDialogState extends State<RejectDialog> {
  TextEditingController commentController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text('Reject Appointment'),
      content: TextField(
        controller: commentController,
        decoration: InputDecoration(hintText: 'Add a comment (optional)'),
      ),
      actions: [
        TextButton(
          onPressed: () {
            Navigator.pop(context);
          },
          child: Text('Cancel'),
        ),
        ElevatedButton(
          onPressed: () {
            widget.onReject(commentController.text);
            Navigator.pop(context);
          },
          child: Text('Reject'),
        ),
      ],
    );
  }
}
