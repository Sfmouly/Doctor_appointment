import 'package:flutter/material.dart';

class AppointmentCard extends StatelessWidget {
  final String patientName;
  final String dateTime;
  final String status;
  final String? doctorComment;
  final VoidCallback? onAccept;
  final VoidCallback? onReject;
  final VoidCallback? onWritePrescription;

  AppointmentCard({
    required this.patientName,
    required this.dateTime,
    required this.status,
    this.doctorComment,
    this.onAccept,
    this.onReject,
    this.onWritePrescription,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 10),
        title: Text('Patient: \$patientName', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Date/Time: \$dateTime'),
            Text('Status: \$status'),
            if (doctorComment != null && doctorComment!.isNotEmpty)
              Text('Comment: \$doctorComment'),
          ],
        ),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (status == 'pending') ...[
              IconButton(
                icon: Icon(Icons.check, color: Colors.green),
                onPressed: onAccept,
              ),
              IconButton(
                icon: Icon(Icons.close, color: Colors.red),
                onPressed: onReject,
              ),
            ],
            if (status == 'accepted')
              IconButton(
                icon: Icon(Icons.medical_services, color: Colors.blue),
                onPressed: onWritePrescription,
              ),
          ],
        ),
      ),
    );
  }
}
