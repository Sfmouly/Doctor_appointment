import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../services/firebase_service.dart';
import 'widgets/doctor_card.dart';
import 'widgets/appointment_card.dart';

class PatientDashboardScreen extends StatefulWidget {
  final String patientId;

  PatientDashboardScreen({required this.patientId});

  @override
  _PatientDashboardScreenState createState() => _PatientDashboardScreenState();
}

class _PatientDashboardScreenState extends State<PatientDashboardScreen> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseService _firebaseService = FirebaseService();

  Stream<QuerySnapshot> getDoctors() {
    return _firestore.collection('doctors').snapshots();
  }

  Stream<QuerySnapshot> getAppointments() {
    return _firestore
        .collection('appointments')
        .where('patientId', isEqualTo: widget.patientId)
        .snapshots();
  }

  void _showRequestAppointmentDialog(String doctorId, String doctorName) {
    TextEditingController symptomsController = TextEditingController();

    showDialog(
      context: context,
      builder:
          (context) => AlertDialog(
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(20),
            ),
            title: Text('Request Appointment with \$doctorName'),
            content: TextField(
              controller: symptomsController,
              decoration: InputDecoration(
                hintText: 'Describe your symptoms',
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                filled: true,
                fillColor: Colors.grey[100],
              ),
              maxLines: 3,
            ),
            actions: [
              TextButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: Text(
                  'Cancel',
                  style: TextStyle(color: Colors.grey[700]),
                ),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade700,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                onPressed: () {
                  _firestore.collection('appointments').add({
                    'patientId': widget.patientId,
                    'doctorId': doctorId,
                    'doctorName': doctorName,
                    'status': 'pending',
                    'dateTime': DateTime.now().toIso8601String(),
                    'symptoms': symptomsController.text,
                    'createdAt': FieldValue.serverTimestamp(),
                  });
                  Navigator.pop(context);
                },
                child: Text('Request'),
              ),
            ],
          ),
    );
  }

  Widget buildDoctorList() {
    return StreamBuilder<QuerySnapshot>(
      stream: getDoctors(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error loading doctors',
              style: TextStyle(color: Colors.red),
            ),
          );
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        final doctors = snapshot.data!.docs;
        if (doctors.isEmpty) {
          return Center(child: Text('No doctors available'));
        }
        return ListView.builder(
          shrinkWrap: true,
          itemCount: doctors.length,
          itemBuilder: (context, index) {
            var doctor = doctors[index];
            var data = doctor.data() as Map<String, dynamic>;
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 6,
              margin: EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                title: Text(
                  data['name'] ?? 'Unknown',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(data['specialization'] ?? ''),
                trailing: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue.shade700,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12),
                    ),
                  ),
                  onPressed: () {
                    _showRequestAppointmentDialog(
                      doctor.id,
                      data['name'] ?? 'Doctor',
                    );
                  },
                  child: Text('Request'),
                ),
              ),
            );
          },
        );
      },
    );
  }

  Widget buildAppointmentList() {
    return StreamBuilder<QuerySnapshot>(
      stream: getAppointments(),
      builder: (context, snapshot) {
        if (snapshot.hasError) {
          return Center(
            child: Text(
              'Error loading appointments',
              style: TextStyle(color: Colors.red),
            ),
          );
        }
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }
        final appointments = snapshot.data!.docs;
        if (appointments.isEmpty) {
          return Center(child: Text('No appointments found'));
        }
        return ListView.builder(
          shrinkWrap: true,
          itemCount: appointments.length,
          itemBuilder: (context, index) {
            var appointment = appointments[index];
            var data = appointment.data() as Map<String, dynamic>;
            return Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
              elevation: 6,
              margin: EdgeInsets.symmetric(vertical: 8),
              child: ListTile(
                title: Text('Appointment with Dr. ${data['doctorName'] ?? ''}'),
                subtitle: Text('Status: ${data['status'] ?? ''}'),
                onTap: () {
                  // TODO: Navigate to prescription view if appointment completed
                },
              ),
            );
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Patient Dashboard'),
        backgroundColor: Colors.blue.shade700,
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Available Doctors',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue.shade900,
                ),
              ),
              SizedBox(height: 10),
              Container(height: 300, child: buildDoctorList()),
              SizedBox(height: 30),
              Text(
                'Your Appointments',
                style: TextStyle(
                  fontSize: 22,
                  fontWeight: FontWeight.bold,
                  color: Colors.blue.shade900,
                ),
              ),
              SizedBox(height: 10),
              Container(height: 300, child: buildAppointmentList()),
            ],
          ),
        ),
      ),
    );
  }
}
