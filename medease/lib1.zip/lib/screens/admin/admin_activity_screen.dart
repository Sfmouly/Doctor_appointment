// TODO Implement this library.
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class AdminActivityScreen extends StatelessWidget {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;

  Stream<QuerySnapshot> getRecentActivities() {
    // Combine recent activities from users, appointments, and prescriptions
    // For simplicity, fetch recent appointments and prescriptions as activities
    return _firestore
        .collection('appointments')
        .orderBy('createdAt', descending: true)
        .limit(20)
        .snapshots();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Activity Monitoring')),
      body: StreamBuilder<QuerySnapshot>(
        stream: getRecentActivities(),
        builder: (context, snapshot) {
          if (snapshot.hasError) {
            return Center(child: Text('Error loading activities'));
          }
          if (snapshot.connectionState == ConnectionState.waiting) {
            return Center(child: CircularProgressIndicator());
          }
          final activities = snapshot.data!.docs;
          if (activities.isEmpty) {
            return Center(child: Text('No recent activities found'));
          }
          return ListView.builder(
            itemCount: activities.length,
            itemBuilder: (context, index) {
              var activity = activities[index];
              var data = activity.data() as Map<String, dynamic>;
              String description = '';
              if (data['status'] != null) {
                description =
                    'Appointment with Dr. ${data['doctorName']} is ${data['status']}';
              }
              return ListTile(
                title: Text(description),
                subtitle: Text('Patient ID: ${data['patientId'] ?? 'N/A'}'),
                trailing: Text(
                  data['createdAt'] != null
                      ? (data['createdAt'] as Timestamp).toDate().toString()
                      : '',
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
